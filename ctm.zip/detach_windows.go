// detach_windows.go
//go:build windows
// +build windows

package main

func detachProcess() {
	// No-op for Windows
}
